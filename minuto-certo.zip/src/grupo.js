import { useEffect, useRef } from 'react';
import { AppState, Alert } from 'react-native';
import * as Crypto from 'expo-crypto';
import { lerJSON, salvarJSON, CHAVES } from './armazenamento';
import { SERVIDOR, cabecalhos, renovarIdentidade } from './nuvem';

const PADRAO = { conectado: false, ultimo: 0 };
const MAX_FILA = 200;

let conectado = false;
let desvio = 0;
let cicloAtual = null;
let fila = []; // ações de pagamento que não chegaram ao servidor (guardadas também no celular)

export const estaConectado = () => conectado;
export const doServidor = (ms) => ms - desvio;
export const pendente = (item) => fila.some((f) => f.item === item);
export const sincronizarAgora = () => (cicloAtual ? cicloAtual() : undefined);

const gravarFila = () => salvarJSON(CHAVES.grupoFila, fila);
const filaPronta = lerJSON(CHAVES.grupoFila, []).then((l) => {
  fila = Array.isArray(l) ? [...l, ...fila].slice(-MAX_FILA) : fila;
});

async function chamar(metodo, caminho, corpo, tentativa = 0) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 20000);
  const t0 = Date.now();
  try {
    const r = await fetch(`${SERVIDOR}/grupo${caminho}`, {
      method: metodo,
      signal: ctl.signal,
      headers: await cabecalhos(),
      body: corpo ? JSON.stringify(corpo) : undefined,
    });
    const t1 = Date.now();
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && j.codigo === 'aparelho' && tentativa === 0) {
      await renovarIdentidade();
      return chamar(metodo, caminho, corpo, 1);
    }
    if (Number.isFinite(j.agora)) desvio = j.agora - Math.round((t0 + t1) / 2);
    return { ...j, status: r.status, ok: r.ok && j.ok !== false };
  } catch (e) {
    return {
      ok: false, status: 0, offline: true,
      erro: e.name === 'AbortError' ? 'O servidor demorou. Tente de novo.' : 'Sem conexão com o servidor.',
    };
  } finally {
    clearTimeout(timer);
  }
}

export const lerLocal = () => lerJSON(CHAVES.grupo, PADRAO);
const gravar = async (v) => {
  conectado = !!v.conectado;
  await salvarJSON(CHAVES.grupo, v);
  if (!conectado) { fila = []; await gravarFila(); }
};
lerLocal().then((l) => { conectado = !!l.conectado; });

// O código tem sempre 6 dígitos (o parâmetro fica só por compatibilidade com telas antigas).
export async function gerarCodigo() {
  const r = await chamar('POST', '/gerar', {});
  if (r.ok) {
    const loc = await lerLocal();
    if (!loc.conectado) await gravar({ conectado: true, ultimo: r.ultimo || 0 });
  }
  return r;
}

export async function entrarComCodigo(codigo) {
  const r = await chamar('POST', '/entrar', { codigo });
  if (r.ok) await gravar({ conectado: true, ultimo: r.ultimo || 0 });
  return r;
}

export async function sairDoGrupo() {
  const loc = await lerLocal();
  if (!loc.conectado) return { ok: true };
  const r = await chamar('POST', '/sair');
  if (r.offline) return { ok: false, erro: 'Conecte-se à internet para desconectar.' };
  await gravar(PADRAO);
  return { ok: true };
}

// só o aparelho principal pode: desconecta todos os outros aparelhos do grupo
export const removerOutrosAparelhos = () => chamar('POST', '/remover');

export const estadoGrupo = (comDados = false) => chamar('GET', `/estado${comDados ? '?dados=1' : ''}`);

export async function enviarEvento({ item, tipo, baseSeq, dados, uid }) {
  const id = uid || Crypto.randomUUID();
  const r = await chamar('POST', '/evento', { item_id: item, tipo, base_seq: baseSeq, dados: dados || {}, evento_uid: id });
  return { ...r, uid: id };
}

// resultado de uma ação aceita pelo servidor -> campos do item local
export function patchDe(tipo, r) {
  const d = r.dados || {};
  const base = { seq: r.seq };
  if (tipo === 'iniciar') return { ...base, status: 'rodando', inicio: doServidor(d.em), acumulado: 0 };
  if (tipo === 'retomar') return { ...base, status: 'rodando', inicio: doServidor(d.em) };
  if (tipo === 'pausar') return { ...base, status: 'pausado', inicio: 0, acumulado: d.total_ms };
  if (tipo === 'encerrar') return { ...base, status: 'finalizado', inicio: 0, acumulado: d.total_ms };
  if (tipo === 'liberar') return { ...base, status: 'livre', inicio: 0, acumulado: 0 };
  if (tipo === 'tempo') return { ...base, limite: d.limite };
  return base;
}
// estado de um item no servidor -> campos do item local
const STATUS_LOCAL = { rodando: 'rodando', pausado: 'pausado', finalizado: 'finalizado', parado: 'livre' };
export const patchDoServidor = (i) => ({
  seq: i.seq,
  status: STATUS_LOCAL[i.status] || 'livre',
  inicio: i.inicio ? doServidor(i.inicio) : 0,
  acumulado: i.acumulado,
});

// Faz a ação: sem grupo aplica local; com grupo o servidor decide. Devolve true se valeu.
// suave: usado em pagamento/ajuste; nunca bloqueia (conflito ou falta de internet aplicam local).
export async function executar({ item, tipo, base, dados, local, aplicar, suave }) {
  if (!conectado) { local(); return true; }
  let b = base || 0;
  let r = await enviarEvento({ item, tipo, baseSeq: b, dados });
  if (r.conflito && suave && r.estado !== 'parado') {
    b = r.seq;
    r = await enviarEvento({ item, tipo, baseSeq: b, dados });
  }
  if (r.ok) { aplicar(patchDe(tipo, r)); return true; }
  if (suave) {
    if (!r.conflito) {
      await filaPronta;
      fila.push({ item, tipo, baseSeq: b, dados, uid: r.uid });
      fila = fila.slice(-MAX_FILA);
      await gravarFila();
    }
    local();
    return true;
  }
  if (r.conflito) {
    Alert.alert('Atenção', r.erro);
    sincronizarAgora();
    return false;
  }
  Alert.alert('Sem conexão', `Com o aparelho conectado, esta ação precisa de internet. ${r.erro || ''}`);
  return false;
}

async function esvaziarFila() {
  await filaPronta;
  let mudou = false;
  for (const f of [...fila]) {
    const r = await enviarEvento(f);
    if (r.ok || r.conflito) { fila.splice(fila.indexOf(f), 1); mudou = true; } else break;
  }
  if (mudou) await gravarFila();
}

// consulta o servidor a cada 4 s e ao voltar para o app
export function useGrupo(ativo, aoReceber) {
  const cb = useRef(aoReceber);
  cb.current = aoReceber;

  useEffect(() => {
    if (!ativo) return undefined;
    let vivo = true;
    let rodando = false;

    const ciclo = async () => {
      if (rodando || AppState.currentState !== 'active') return;
      rodando = true;
      try {
        const loc = await lerLocal();
        if (!loc.conectado) return;
        await esvaziarFila();
        const r = await chamar('GET', `/eventos?depois=${loc.ultimo || 0}`);
        if (!vivo || !r.ok) return;
        if (r.conectado === false) {
          await gravar(PADRAO);
          cb.current?.({ desconectado: true });
          return;
        }
        if (r.ultimo !== loc.ultimo) await gravar({ ...loc, ultimo: r.ultimo });
        cb.current?.({ itens: r.itens || [], eventos: r.eventos || [] });
      } finally {
        rodando = false;
      }
    };

    cicloAtual = ciclo;
    ciclo();
    const id = setInterval(ciclo, 4000);
    const sub = AppState.addEventListener('change', (e) => { if (e === 'active') ciclo(); });
    return () => { vivo = false; cicloAtual = null; clearInterval(id); sub.remove(); };
  }, [ativo]);
}